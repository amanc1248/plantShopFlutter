class PlantDetails{
  int iN;
  String ca;
  String pN;
  String des;
  int pr;
  PlantDetails({int indexNumber,String category,String plantName, String description, int price}){
     iN = indexNumber;
     ca = category;
     pN  = plantName;
     des = description;
     pr =price;
  }
}
class TopPlants{
    int iN;
  String ca;
  String pN;
  String des;
  int pr;
  TopPlants({int indexNumber,String category,String plantName, String description, int price}){
     iN = indexNumber;
     ca = category;
     pN  = plantName;
     des = description;
     pr =price;
  }
}

class CartPlantLists{
     int iN;
  String ca;
  String pN;
  int pr;
  int qu = 0;
  CartPlantLists({int indexNumber,String category,String plantName, int quantity, int price}){
     qu = quantity;
     iN = indexNumber;
     ca = category;
     pN  = plantName;
     pr =price;
  }
}