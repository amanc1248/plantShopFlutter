import 'package:flutter/material.dart';
import 'listClasses.dart';
import 'lists.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'TopAppBar.dart';
import 'package:provider/provider.dart';
import 'viewTotalItem.dart';
import 'cartScreen.dart';
ViewTotalItemProvider viewTotalItemProvider = ViewTotalItemProvider();

OurAllLists ourAllLists = OurAllLists();

class PlantFeatureScreen1 extends StatefulWidget {
  @override
  _PlantFeatureScreen1State createState() => _PlantFeatureScreen1State();
}

class _PlantFeatureScreen1State extends State<PlantFeatureScreen1> {
  @override
  Widget build(BuildContext context) {
    final ViewTotalItemProvider viewTotalItemProvider =
        Provider.of<ViewTotalItemProvider>(context, listen: false);

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 20, 10, 0),
      child: Column(
        children: <Widget>[
          TopAppBar(),
          Expanded(
            flex: 1,
            child: Align(
              alignment: Alignment(-1, 0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                ),
                child: Text(
                  "Plants",
                  style: TextStyle(fontSize: 33, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 5,
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
              ),
              child: DefaultTabController(
                
                length: 5,
                child: Column(
                  children: [
                    Container(
                      height: 50,
                      width: double.infinity,
                      child: TabBar(
                        labelColor: Colors.black,
                        indicatorColor: Color(0xFF96CA2D),
                        indicatorSize:  TabBarIndicatorSize.label,
                        indicatorPadding: EdgeInsets.fromLTRB(30, 0, 30, 0),
                        
                        isScrollable: true,
                        tabs: ourAllLists.tabMaker(),
                      ),
                    ),
                    Container(
                      height: 400,
                      width: double.infinity,
                      decoration: BoxDecoration(color: Colors.white),
                      child: TabBarView(
                        children: ourAllLists.tabViewerMaker(context),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 0, 20),
            child: FlatButton(
              onPressed: (){
                Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartDetais3()),
              );
              },
                          child: Container(
                alignment: Alignment.bottomRight,
                height: 88,
                width: double.infinity,
                child: Stack(
                  overflow: Overflow.visible,
                  children: [
                    Container(
                      height: 70,
                      width: 105,
                      decoration: BoxDecoration(
                          color: Color(0xFF96CA2D),
                          borderRadius: BorderRadiusDirectional.horizontal(
                              end: Radius.circular(32),
                              start: Radius.circular(32))),
                      child: Icon(FontAwesomeIcons.shoppingBag,
                          color: Colors.white, size: 30),
                    ),
                    Positioned(
                      // top: 0,
                      bottom: 50,
                      right: 0,
                      child: Consumer<ViewTotalItemProvider>(
                          builder: (context, value, child) {
                        return Container(
                          height: 35,
                          width: 35,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(50),
                              border:
                                  Border.all(color: Color(0xFF96CA2D), width: 4)),
                          child: Center(
                              child: Text(
                                  viewTotalItemProvider.totalquantity().toString(),
                                  style: TextStyle(
                                      fontSize: 20, color: Color(0xFF96CA2D)))),
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
