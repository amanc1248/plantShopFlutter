import 'package:flutter/material.dart';
const kPlantNameStyle = TextStyle(
                        fontSize: 35,
                        fontWeight: FontWeight.w700,
                      );
const kItemPrice = TextStyle(
                          fontSize: 33,
                          color: Color(0xFF96CA2D),
                          fontWeight: FontWeight.w800);