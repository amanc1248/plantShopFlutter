import 'package:flutter/material.dart';
import 'package:plantshop/particularPlant2.dart';
import 'listClasses.dart';

class OurAllLists {
  List<String> tabsText = ["Top", "Outdoor", "Indoor", "Seeds", "Flowers"];
  List<PlantDetails> mainListAllPlantDetailsList1 = [
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the Lamb's Ear flowerThis is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description:
            "This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi ",
        price: 147,
        description:
            "This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor "),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "lily",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "lily",
        price: 120,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi",
        price: 147,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "lily",
        price: 120,
        description: "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor"),
  ];
  List<TopPlants> topPlantsList2 = [
    TopPlants(
        category: "Outdoor",
        plantName: "lily",
        price: 120,
        description: "This is the lily outdoor")
  ];
  //this is tab maker
  tabMaker() {
    List<Tab> tabs = List();
    for (var i = 0; i < tabsText.length; i++) {
      tabs.add(Tab(
        text: tabsText[i],
      ));
    }
    return tabs;
  }

  //this is tabviewer maker
  tabViewerMaker(BuildContext context) {
    List<ListView> tabBarView = List();
    for (var i = 0; i < tabsText.length; i++) {
      tabBarView.add(
        ListView(
            scrollDirection: Axis.horizontal,
            children: containerAdder(i, context)),
      );
    }
    return tabBarView;
  }

//this is for adding container to the listview
  containerAdder(initialI, BuildContext context) {
    List<Widget> listViewContainer = List();

    for (var j = 0; j < mainListAllPlantDetailsList1.length; j++) {
      if (tabsText[initialI] == mainListAllPlantDetailsList1[j].ca) {
        listViewContainer.add(Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            FlatButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ParticularPlant2(
                            indexNumber: j,
                          )),
                );
              },
              child: Container(
                  height: 320,
                  width: 200,
                  child: Stack(
                    children: [
                      Positioned(
                        bottom: 10,
                        child: Container(
                          padding: EdgeInsets.fromLTRB(25, 50, 20, 20),
                          height: 160,
                          width: 200,
                          decoration: BoxDecoration(
                            color: Colors.lightGreen,
                            borderRadius: BorderRadiusDirectional.only(
                              bottomEnd: Radius.circular(70),
                              topEnd: Radius.circular(70),
                              topStart: Radius.circular(70),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                mainListAllPlantDetailsList1[j].ca,
                                style: TextStyle(
                                    color: Color(0xFFC8E392), fontSize: 15),
                              ),
                              Text(
                                mainListAllPlantDetailsList1[j].pN,
                                style: TextStyle(
                                    color: Color(0xFFEAF4D5), fontSize: 25),
                              ),
                              Text(
                                  "\$" +
                                      mainListAllPlantDetailsList1[j]
                                          .pr
                                          .toString(),
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 30,
                                      fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      )
                    ],
                  )),
            ),
            Container(
              height: 50,
              width: 250,
              child: Text(
                mainListAllPlantDetailsList1[j].des,
                style: TextStyle(
                  fontSize: 15,
                ),
              ),
            )
          ],
        )));
      } else {
        continue;
      }
    }
    return listViewContainer;
  }

//for calculating the total no. of items.

  // for calculating the total cost
}
