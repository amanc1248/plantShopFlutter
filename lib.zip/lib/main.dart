import 'package:flutter/material.dart';
import 'package:plantshop/viewTotalItem.dart';
import 'package:provider/provider.dart';
import 'plantFeatureScreen1.dart';
import 'package:provider/provider.dart';
import 'viewTotalItem.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
            ChangeNotifierProvider<ViewTotalItemProvider>(create: (context) => ViewTotalItemProvider()),
        ],
          child: MaterialApp(
        home: SafeArea(
                child: Scaffold(
                  backgroundColor: Colors.white,
            body: PlantFeatureScreen1(),
          ),
        )
        ),
    ); // This trailing comma makes auto-formatting nicer for build methods.
  
  }
}
