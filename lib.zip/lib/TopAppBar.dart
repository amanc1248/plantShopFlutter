import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'cartScreen.dart';
class TopAppBar extends StatelessWidget {
  const TopAppBar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
      ),
      child: ListTile(
        leading: Icon(
          FontAwesomeIcons.airbnb,
          size: 35,
          color: Color(0xFFC1C2C4),
        ),
        trailing: FlatButton(
          onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CartDetais3()),
              );
            },
                  child: Icon(
            Icons.search,
            size: 35,
            color: Color(0xFFC1C2C4),
          ),
        ),
      ),
    );
  }
}
