import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:plantshop/listClasses.dart';
import 'package:plantshop/lists.dart';
import 'TopAppBar.dart';
import 'constants.dart';
import 'viewTotalItem.dart';
import 'package:provider/provider.dart';

OurAllLists ourAllLists = OurAllLists();
ViewTotalItemProvider viewTotalItemProvider = ViewTotalItemProvider();

class ParticularPlant2 extends StatefulWidget {
  final indexNumber;
  ParticularPlant2({@required this.indexNumber});
  @override
  _ParticularPlant2State createState() => _ParticularPlant2State();
}

class _ParticularPlant2State extends State<ParticularPlant2> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          body: Padding(
            padding: const EdgeInsets.fromLTRB(12, 15, 12, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TopAppBar(),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadiusDirectional.only(
                      bottomStart: Radius.circular(50),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        ourAllLists
                            .mainListAllPlantDetailsList1[widget.indexNumber]
                            .pN,
                        style: kPlantNameStyle,
                      ),
                      SizedBox(
                        height: 13,
                      ),
                      Text(
                        ourAllLists
                            .mainListAllPlantDetailsList1[widget.indexNumber].ca
                            .toUpperCase(),
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      ),
                      SizedBox(height: 16),
                      Text(
                        "\$" +
                            ourAllLists
                                .mainListAllPlantDetailsList1[
                                    widget.indexNumber]
                                .pr
                                .toString(),
                        style: kItemPrice,
                      ),
                      SizedBox(height: 100),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                height: 70,
                                width: 70,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(50),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 5,
                                      blurRadius: 7,
                                      offset: Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  FontAwesomeIcons.flag,
                                  color: Color(0xFF9DCD3C),
                                ),
                              ),
                              SizedBox(
                                height: 50,
                              ),
                              FlatButton(
                                onPressed: () {
                                  final ViewTotalItemProvider
                                      viewTotalItemProvider =
                                      Provider.of<ViewTotalItemProvider>(
                                          context,
                                          listen: false);
                                  final tile = viewTotalItemProvider
                                      .cartPlantList3
                                      .firstWhere(
                                          (item) =>
                                              item.pN ==
                                              ourAllLists
                                                  .mainListAllPlantDetailsList1[
                                                      widget.indexNumber]
                                                  .pN,
                                          orElse: () => null);
                                  if (tile != null) {
                                  } else {
                                    viewTotalItemProvider.addItems(
                                      CartPlantLists(
                                        quantity: 1,
                                        plantName: ourAllLists
                                            .mainListAllPlantDetailsList1[
                                                widget.indexNumber]
                                            .pN,
                                        category: ourAllLists
                                            .mainListAllPlantDetailsList1[
                                                widget.indexNumber]
                                            .ca,
                                        price: ourAllLists
                                            .mainListAllPlantDetailsList1[
                                                widget.indexNumber]
                                            .pr,
                                      ),
                                    );
                                  }

                                  print(viewTotalItemProvider
                                      .cartPlantList3.length);
                                },
                                child: Container(
                                  height: 80,
                                  width: 80,
                                  decoration: BoxDecoration(
                                      color: Color(0xFF9DCD3C),
                                      borderRadius: BorderRadius.circular(50)),
                                  child: Icon(FontAwesomeIcons.shoppingBag,
                                      color: Colors.white),
                                ),
                              )
                            ],
                          ),
                          Container(
                            height: 250,
                            child: Image(image: AssetImage("assets/tulip.png")),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
