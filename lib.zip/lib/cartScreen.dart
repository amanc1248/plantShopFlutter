import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:plantshop/viewTotalItem.dart';
import 'TopAppBar.dart';
import 'constants.dart';
import 'lists.dart';
import 'viewTotalItem.dart';
import 'package:provider/provider.dart';

OurAllLists ourAllLists = OurAllLists();

class CartDetais3 extends StatefulWidget {

  @override
  _CartDetais3State createState() => _CartDetais3State();
}

class _CartDetais3State extends State<CartDetais3> {
  @override
  Widget build(BuildContext context) {
    final ViewTotalItemProvider viewTotalItemProvider = Provider.of<ViewTotalItemProvider>(context);
    return MaterialApp(
        home: SafeArea(
            child: Scaffold(
              backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.fromLTRB(8, 20, 8, 15),
        child: Column(
          children: [
            TopAppBar(),
            SizedBox(height: 20,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Cart",
                  style: kPlantNameStyle,
                ),
                Text(
                  "\$",
                  style: kItemPrice,
                ),
              ],
            ),
            SizedBox(height: 20,),
            Expanded(
              child: ListView.builder(
                  itemCount: viewTotalItemProvider.cartPlantList3.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: 110,
                            width: 100,
                            child: Image(image: AssetImage("assets/tulip.png")),
                          ),
                          Container(
                            height: 100,
                            width: 120,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text( viewTotalItemProvider.cartPlantList3[index].pN,style:TextStyle(fontSize:20,fontWeight: FontWeight.w700)),
                                SizedBox(height: 8,),
                                Text(viewTotalItemProvider.cartPlantList3[index].ca
                                    .toUpperCase(),style: TextStyle(fontSize:15),),
                                    SizedBox(height: 15,),
                                Text("\$ " +viewTotalItemProvider.cartPlantList3[index].pr
                                        .toString(),style: TextStyle(fontSize:20),),
                              ],
                            ),
                          ),
                          Container(
                              height: 120,
                              child: Column(
                                children: [
                                  FlatButton(
                                    onPressed: () {
                                      viewTotalItemProvider.addQuantity(index);
                                    },
                                    child: Icon(
                                      FontAwesomeIcons.plus,
                                      size: 20,
                                    ),
                                  ),
                                  Text(viewTotalItemProvider.cartPlantList3[index].qu
                                      .toString()),
                                  FlatButton(
                                    onPressed: () {
                                        viewTotalItemProvider
                                            .subtrachQuantity(index);
                                    },
                                    child: Icon(
                                      FontAwesomeIcons.minus,
                                      size: 20,
                                    ),
                                  ),
                                ],
                              ))
                        ],
                      ),
                    );
                  }),
            ),
            Container(
              alignment: Alignment.bottomRight,
              height: 50,
              width: 150,
              decoration: BoxDecoration(
                color:Color(0xFF96CA2D),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                Text("Checkout",style: TextStyle(fontSize:20,color:Colors.white,fontWeight: FontWeight.w600)),
                Icon(FontAwesomeIcons.arrowRight,color: Colors.white,)
              ],),
            )
          ],
        ),
      ),
    )));
  }
}
