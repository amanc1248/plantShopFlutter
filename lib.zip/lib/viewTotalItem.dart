import 'package:flutter/material.dart';
import 'listClasses.dart';

class ViewTotalItemProvider extends ChangeNotifier {
  List<CartPlantLists> _cartPlantList3 = [];
  List<CartPlantLists> get cartPlantList3 => _cartPlantList3;

  set cartPlantList3(List<CartPlantLists> val) {
    _cartPlantList3 = val;
    notifyListeners();
  }

  addQuantity(index) {
    _cartPlantList3[index].qu++;
    notifyListeners();
  }

  subtrachQuantity(index) {
    _cartPlantList3[index].qu--;
    notifyListeners();
  }

  int totalquantity() {
    int totalItems = 0;
    for (var i = 0; i < cartPlantList3.length; i++) {
      totalItems = totalItems + cartPlantList3[i].qu;
    }
    return totalItems;
  }

  addItems(CartPlantLists myList) {
    cartPlantList3.add(myList);
    notifyListeners();
  }
}
