

import 'listClasses.dart';

class OurAllLists {

  List<String> tabsText = ["Top", "Outdoor", "Indoor", "Seeds", "Flowers"];
  List<PlantDetails> mainListAllPlantDetailsList1 = [
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the Lamb's Ear Top This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower ",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the Lamb's Ear flower This is the Lamb's Ear flower This is the Lamb's Ear flower.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description:
            "This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is the lotus seeds This is.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi ",
        price: 147,
        description:
            "This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor This is the Hughusi Yoon indoor. ",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "Lily",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor ",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description:
           " This is the lily outdoor This is the lily outdoor This is the lily outdoor",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi",
        price: 147,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "Lily",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 0,
        category: "Top",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 0,
        category: "Flowers",
        plantName: "Lamb's Ear",
        price: 147,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 1,
        category: "Seeds",
        plantName: "Lotus",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 2,
        category: "Indoor",
        plantName: "Hughusi",
        price: 147,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
    PlantDetails(
        indexNumber: 3,
        category: "Outdoor",
        plantName: "Lily",
        price: 120,
        description:
            "This is the lily outdoor This is the lily outdoor This is the lily outdoor This is the lily outdoor.",
        plantImage: "assets/flower.png",
        light: "Sunlight",
        water: "Low water",
        temperature: "28* celcius"),
  ];
  List<TopPlants> topPlantsList2 = [
    TopPlants(
        category: "Outdoor",
        plantName: "lily",
        price: 120,
        description: "This is the lily outdoor")
  ];
}     